/*
-- Query: SELECT * FROM SHOP.ship_method
LIMIT 0, 1000

-- Date: 2021-08-06 15:03
*/
INSERT INTO `` (`ship_no`,`ship_name`,`ship_fee`) VALUES (1,'7-11',60);
INSERT INTO `` (`ship_no`,`ship_name`,`ship_fee`) VALUES (2,'全家',60);
INSERT INTO `` (`ship_no`,`ship_name`,`ship_fee`) VALUES (3,'黑貓宅急便',150);
INSERT INTO `` (`ship_no`,`ship_name`,`ship_fee`) VALUES (4,'郵局包裹',100);

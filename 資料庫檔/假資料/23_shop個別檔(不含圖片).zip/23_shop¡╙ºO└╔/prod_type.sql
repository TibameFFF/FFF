/*
-- Query: SELECT * FROM SHOP.prod_type
LIMIT 0, 1000

-- Date: 2021-08-06 15:02
*/
INSERT INTO `` (`prod_type_no`,`type_name`) VALUES (1,'生活休閒');
INSERT INTO `` (`prod_type_no`,`type_name`) VALUES (2,'美妝保養');
INSERT INTO `` (`prod_type_no`,`type_name`) VALUES (3,'風格穿搭');
INSERT INTO `` (`prod_type_no`,`type_name`) VALUES (4,'3C家電');
